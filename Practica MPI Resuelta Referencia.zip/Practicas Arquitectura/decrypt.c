#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define _XOPEN_SOURCE

#define _GNU_SOURCE         /* See feature_test_macros(7) */
#include <crypt.h>
#include "mpi.h"
#include <string.h>
#define MAX 99999999


//char *crypt_r(const char *key, const char *salt, struct crypt_data *data);
char *crypt(const char *key, const char *salt);



void main(int argc,char **argv)
{


char con[9];
unsigned long intentos;
int iId ; 
int iNumProcs;
int rango;


MPI_Init(&argc, &argv);
MPI_Comm_rank(MPI_COMM_WORLD,&iId ); 			
MPI_Comm_size(MPI_COMM_WORLD, & iNumProcs ); 

/*
if (iId == 0) {
	
	rango = MAX / iNumProcs;
	iEtiqueta = 15;
	
	for (i=1;i<iNumProcs;i++) MPI_Send(&ulIntervalo, 1, MPI_UNSIGNED_LONG, i, iEtiqueta, MPI_COMM_WORLD);
	
}


else {	
	iEtiqueta=15;
	MPI_Recv(&ulIntervalo,1, MPI_UNSIGNED_LONG, 0, iEtiqueta, MPI_COMM_WORLD, &status);	

}

*/

if (iId ==  0) {

/*--ESTA ES LA OPERACIÓN--*/
	for (intentos=0; intentos<=MAX; intentos++){
	// genera la contraseña
	sprintf(con,"%08lu",intentos);
	if (strcmp(crypt(con,"aa"),argv[1])==0)
	{
	printf("Encontrada: %s->%s (%lu)\n",argv[1],con, intentos);
	break;
/*--------------------------*/

	}
	}
}


if (iId ==  1) {

/*--ESTA ES LA OPERACIÓN--*/
	for (intentos=0; intentos<=MAX; intentos++){
	// genera la contraseña
	sprintf(con,"%08lu",intentos);
	if (strcmp(crypt(con,"aa"),argv[1])==0)
	{
	printf("Encontrada: %s->%s (%lu)\n",argv[2],con, intentos);
	break;
/*--------------------------*/

	}
	}
}

if (iId ==  2) {

/*--ESTA ES LA OPERACIÓN--*/
	for (intentos=0; intentos<=MAX; intentos++){
	// genera la contraseña
	sprintf(con,"%08lu",intentos);
	if (strcmp(crypt(con,"aa"),argv[1])==0)
	{
	printf("Encontrada: %s->%s (%lu)\n",argv[3],con, intentos);
	break;
/*--------------------------*/

	}
	}
}


if (iId ==  3) {

/*--ESTA ES LA OPERACIÓN--*/
	for (intentos=0; intentos<=MAX; intentos++){
	// genera la contraseña
	sprintf(con,"%08lu",intentos);
	if (strcmp(crypt(con,"aa"),argv[1])==0)
	{
	printf("Encontrada: %s->%s (%lu)\n",argv[4],con, intentos);
	break;
/*--------------------------*/

	}
	}
}

MPI_Finalize(); 
}


/*

mpicc decrypt.c -o decrypt -lcrypt
mpirun -np 4 decrypt “aagWNRh7V9kN6” “aahpg4OwfHMXY” ”aaTwdzPnfU7XE”  “aaxF36GTHquV.”

*/
