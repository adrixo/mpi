#define TAMCADENA 100
#include <stdio.h>
#include <mpi.h>

int main(int argc, char** argv)
{
	/* code */

	int id, nprocs;
	char nombreProc [MPI_MAX_PROCESSOR_NAME];
	int lnombreproc;// Longitud nombre del procesador
	double tmpinic = 0.0; //Tiempo de inicio de la ejecución
	double tmpfin ;


	MPI_Init (&argc, &argv);
	
	MPI_Comm_size (MPI_COMM_WORLD, &nprocs);
	MPI_Comm_rank(MPI_COMM_WORLD, &id);

	MPI_Get_processor_name (nombreProc, &lnombreproc);

	tmpinic = MPI_Wtime (); 
	
	if (id == 0 ){
	fprintf(stdout, "Proceso %d en %s \n", id, nombreProc );	
	fprintf(stdout, "Numero de Procesos: %d \n",nprocs );

	}

	tmpfin  = MPI_Wtime ();

	if (id == 0 )	fprintf(stdout, "Tiempo Procesamiento: %f \n\n",tmpfin - tmpinic );

	
	return 0;
}